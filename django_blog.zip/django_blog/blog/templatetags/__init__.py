# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     __init__.py  
   Description :  
   Author :       JHao
   date：          2017/4/14
-------------------------------------------------
   Change Activity:
                   2017/4/14: 
-------------------------------------------------
"""
__author__ = 'JHao'

import sys

reload(sys)
sys.setdefaultencoding('utf-8')

if __name__ == '__main__':
    pass