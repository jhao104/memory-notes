# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     urls.py  
   Description :  
   Author :       JHao
   date：          2017/4/13
-------------------------------------------------
   Change Activity:
                   2017/4/13: 
-------------------------------------------------
"""
__author__ = 'JHao'

from blog import views
from django.conf.urls import url

urlpatterns = [

    url(r'^index/$', views.Index, name='index'),
    url(r'^about/$', views.About, name='about'),
    url(r'^archive/$', views.Archive, name='archive'),
    url(r'^link/$', views.Link, name='link'),
    url(r'^message/$', views.Message, name='message'),
    url(r'^article/(?P<pk>\d+)$', views.Articles, name='article'),
    url(r'^get_comment/$', views.GetComment, name='get_comment'),
    url(r'.*?$', views.Index, name='index'),
]
